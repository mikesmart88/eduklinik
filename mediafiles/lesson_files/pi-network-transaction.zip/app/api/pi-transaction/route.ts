import { NextResponse } from "next/server"
import crypto from "crypto"

// Pi Network API configuration
const PI_API_URL = process.env.PI_API_URL || "https://api.minepi.com"
const PI_API_KEY = process.env.PI_API_KEY
const PI_APP_SECRET = process.env.PI_APP_SECRET

// Function to generate authentication headers
function generateAuthHeaders() {
  const timestamp = Math.floor(Date.now() / 1000).toString()
  const payload = `${PI_API_KEY}${timestamp}`
  const signature = crypto
    .createHmac("sha256", PI_APP_SECRET || "")
    .update(payload)
    .digest("hex")

  return {
    "Content-Type": "application/json",
    "X-Pi-API-Key": PI_API_KEY || "",
    "X-Pi-Timestamp": timestamp,
    "X-Pi-Signature": signature,
  }
}

// Function to submit a transaction to Pi Network
async function submitTransaction(paymentData: any) {
  try {
    // Step 1: Create a payment
    const createPaymentResponse = await fetch(`${PI_API_URL}/v2/payments`, {
      method: "POST",
      headers: generateAuthHeaders(),
      body: JSON.stringify(paymentData),
    })

    if (!createPaymentResponse.ok) {
      const errorData = await createPaymentResponse.json()
      throw new Error(`Failed to create payment: ${JSON.stringify(errorData)}`)
    }

    const payment = await createPaymentResponse.json()
    const paymentId = payment.identifier

    // Step 2: Submit the transaction to the blockchain
    const submitResponse = await fetch(`${PI_API_URL}/v2/payments/${paymentId}/submit`, {
      method: "POST",
      headers: generateAuthHeaders(),
    })

    if (!submitResponse.ok) {
      const errorData = await submitResponse.json()
      throw new Error(`Failed to submit transaction: ${JSON.stringify(errorData)}`)
    }

    return await submitResponse.json()
  } catch (error) {
    console.error("Error submitting transaction:", error)
    throw error
  }
}

export async function POST(request: Request) {
  if (!PI_API_KEY || !PI_APP_SECRET) {
    return NextResponse.json({ error: "Pi Network API credentials not configured" }, { status: 500 })
  }

  try {
    const paymentData = await request.json()

    // Validate the payment data
    if (!paymentData.amount || !paymentData.recipient) {
      return NextResponse.json({ error: "Missing required payment information" }, { status: 400 })
    }

    const result = await submitTransaction(paymentData)
    return NextResponse.json({ success: true, data: result })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to process transaction" }, { status: 500 })
  }
}
