"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle, CheckCircle2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function TransactionForm() {
  const [amount, setAmount] = useState("")
  const [recipient, setRecipient] = useState("")
  const [memo, setMemo] = useState("")
  const [metadata, setMetadata] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      // Parse metadata as JSON if provided
      let parsedMetadata = {}
      if (metadata.trim()) {
        try {
          parsedMetadata = JSON.parse(metadata)
        } catch (error) {
          setResult({
            success: false,
            message: "Invalid JSON in metadata field",
          })
          setLoading(false)
          return
        }
      }

      const response = await fetch("/api/pi-transaction", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: Number.parseFloat(amount),
          recipient,
          memo: memo || "Payment via Pi Network",
          metadata: parsedMetadata,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setResult({
          success: true,
          message: "Transaction submitted successfully!",
        })
        // Reset form
        setAmount("")
        setRecipient("")
        setMemo("")
        setMetadata("")
      } else {
        setResult({
          success: false,
          message: data.error || "Failed to submit transaction",
        })
      }
    } catch (error) {
      setResult({
        success: false,
        message: "An error occurred while processing your request",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Submit Pi Network Transaction</CardTitle>
        <CardDescription>Send Pi tokens to another user on the Pi Network blockchain</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="amount">Amount (Pi)</Label>
            <Input
              id="amount"
              type="number"
              step="0.000001"
              min="0"
              placeholder="1.0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="recipient">Recipient Username</Label>
            <Input
              id="recipient"
              placeholder="username"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="memo">Memo (Optional)</Label>
            <Input id="memo" placeholder="Payment for goods" value={memo} onChange={(e) => setMemo(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="metadata">Metadata - JSON (Optional)</Label>
            <Textarea
              id="metadata"
              placeholder='{"orderId": "12345"}'
              value={metadata}
              onChange={(e) => setMetadata(e.target.value)}
              className="min-h-[80px]"
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Processing..." : "Submit Transaction"}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex flex-col">
        {result && (
          <Alert variant={result.success ? "default" : "destructive"} className="mt-4">
            {result.success ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
            <AlertTitle>{result.success ? "Success" : "Error"}</AlertTitle>
            <AlertDescription>{result.message}</AlertDescription>
          </Alert>
        )}
      </CardFooter>
    </Card>
  )
}
